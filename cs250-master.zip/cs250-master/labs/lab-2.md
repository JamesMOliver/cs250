### CS250 Introduction to C Programming<br> Capitol Technology University
--
### Lab 2<br>

**Instructions**: Respond to the prompt below in writing and submit to the course portal in Canvas. Written responses are expected to be full, complete statements that exemplify a quality commensurate with collegiate level articulation. See the course syllabus for specific grading criteria.

**Prompt**: Analyze the following code and explain what is missing. What would you add (be specific) and why?

    struct sockaddr_in {
    
    	unsigned short sin_family;
    	unsigned short sin_port;
    
    }